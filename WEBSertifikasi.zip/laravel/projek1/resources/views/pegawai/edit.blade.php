
@extends('layouts.master')

@section('content')
            <div class="col-lg-12">
            <h1>Edit Data Pegawai</h1>
            @if(session('Berhasil'))
                <div class="alert alert-success" role="alert">
                   {{session('Berhasil')}}
                </div>
            @endif  
            <div class="row">
                
                        <form action="/dataPegawai/{{$pegawai->id}}/update" method="POST">
                            {{csrf_field()}}
                                <div class="mb-3">
                                    <label for="Inputnama" class="form-label">Nama </label>
                                    <input name="nama" type="text" class="form-control" id="Inputnama" aria-describedby="HelpName" 
                                    placeholder="Enter Nama" value="{{$pegawai->Nama}}">
                                </div>
                               
                                <div class="mb-3 form group">
                                    <label for="jk">Jenis Kelamin</label>
                                    <select name="jenis_kelamin" class= "form-control" id="jk">
                                        <option value="Laki-Laki" @if($pegawai->Jenis_Kelamin == 'Laki-Laki') selected @endif>Laki-Laki</option>
                                        <option value="Perempuan" @if($pegawai->Jenis_Kelamin == 'Perempuan') selected @endif>Perempuan</option>

                                    </select>
                                    
                                </div>
                                    
                                <div class="mb-3">
                                    <label for="Inputagama" class="form-label">Agama</label>
                                    <input name="agama" 6type="text" class="form-control" id="Inputagama" aria-describedby="HelpAgama" placeholder="Enter Agama" value="{{$pegawai->Agama}}">
                                </div>

                                <div class="mb-3">
                                    <label for="floatingTextarea2" class="form-label">Alamat</label>
                                    <textarea name="alamat" class="form-control" placeholder="Alamat" id="floatingTextarea2" style="height: 100px" >{{$pegawai->Alamat}}</textarea>
                                    
                                </div> 
                                <button type="submit" class="btn btn-warning">Update</button>
                            </form>
                     </div>
            </div>     
@endsection