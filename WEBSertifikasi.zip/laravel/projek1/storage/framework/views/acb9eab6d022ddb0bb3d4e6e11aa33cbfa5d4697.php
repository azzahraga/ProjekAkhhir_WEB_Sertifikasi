

<?php $__env->startSection('content'); ?>
<!-- Masthead-->
<header class="masthead">
            <div class="container px-4 px-lg-5 d-flex h-100 align-items-center justify-content-center">
                <div class="d-flex justify-content-center">
                    <div class="text-center">
                        <h1 class="mx-auto my-0 text-uppercase">Dananjaya Corp</h1>
                        <h2 class="text-white-50 mx-auto mt-2 mb-5">Web di Perusahaan Dagang yang berisi data para pegawai</h2>
                        <a class="btn btn-primary" href="/dataPegawai">Get Started</a>
                    </div>
                </div>
            </div>
        </header>
    
        <!-- Projects-->
        <section class="projects-section bg-light" id="projects">
            <div class="container px-4 px-lg-5">
                <!-- Featured Project Row-->
                <div class="row gx-0 mb-4 mb-lg-5 align-items-center">
                    <div class="col-xl-8 col-lg-7">
                        <img class="img-fluid mb-3 mb-lg-0" src="assets/img/img4.jpg" alt="..." />
                    </div>
                    <div class="col-xl-4 col-lg-5">
                        <div class="featured-text text-center text-lg-left">
                            <h4>Dananjaya Corp</h4>
                            <p class="text-black-50 mb-0">Dananjaya CORP ini adalah sebauh perusahaan dagang adalah perusahaan yang kegiatan utamanya membeli, menyimpan dan menjual kembali barang dagang tanpa memberikan nilai tambah. </p>
                        </div>
                    </div>
                </div>
                <!-- Project One Row-->
                <div class="row gx-0 mb-5 mb-lg-0 justify-content-center">
                    <div class="col-lg-6"><img class="img-fluid" src="assets/img/img1.jpg" alt="..." /></div>
                    <div class="col-lg-6">
                        <div class="bg-black text-center h-100 project">
                            <div class="d-flex h-100">
                                <div class="project-text w-100 my-auto text-center text-lg-left">
                                    <h4 class="text-white">Company</h4>
                                    <p class="mb-0 text-white-50">Perusahaan membeli suatu produk untuk kemudian dijual kembali tanpa harus melakukan pengubahan terhadap produk-produk tersebut.</p>
                                    <hr class="d-none d-lg-block mb-0 ms-0" />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
        </section>
        

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.masterhome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\projek1\resources\views/sites/home.blade.php ENDPATH**/ ?>