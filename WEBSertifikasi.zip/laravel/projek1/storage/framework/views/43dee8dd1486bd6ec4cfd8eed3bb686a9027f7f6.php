

<?php $__env->startSection('content'); ?>
            <?php if(session('Berhasil')): ?>
                <div class="alert alert-success" role="alert">
                   <?php echo e(session('Berhasil')); ?>

                </div>
            <?php endif; ?>  
            <div class="row">
                <div class="col-6">
                <h1>DATA PEGAWAI</h1> 
                </div>
                <div class="col-6">
                    <button type="button" class="btn btn-primary btn-sm float-end fw-bold" data-bs-toggle="modal" data-bs-target="#exampleModal">
                    Tambah Pegawai
                    </button>
                </div>

                <table class="table table-dark table-hover">
                    <tr style="text-align: center;">
                        <th>NAMA</th>
                        <th>JENIS KELAMIN</th>
                        <th>AGAMA</th>
                        <th>ALAMAT</th>
                        <th>WAKTU DAFTAR</th>
                        <th>AKSI</th>
                    </tr>
                    <?php $__currentLoopData = $data_pegawai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pegawai): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($pegawai->Nama); ?></td>
                        <td><?php echo e($pegawai->Jenis_Kelamin); ?></td>
                        <td><?php echo e($pegawai->Agama); ?></td>
                        <td><?php echo e($pegawai->Alamat); ?></td>
                        <td><?php echo e($pegawai->created_at); ?></td>
                        <td>
                            <a href="/dataPegawai/<?php echo e($pegawai->id); ?>/edit" class="btn btn-warning btn-sm">Edit</a>
                            <a href="/dataPegawai/<?php echo e($pegawai->id); ?>/delete" class="btn btn-danger btn-sm " onclick="return confirm('Yakin ingin hapus data?')">Hapus</a>
                    
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            </div>
        </div>

        <!-- Modal -->
        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Tambah Data Pegawai</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                        <form action="/dataPegawai/create" method="POST">
                            <?php echo e(csrf_field()); ?>

                                <div class="mb-3">
                                    <label for="Inputnama" class="form-label">Nama </label>
                                    <input name="nama" type="text" class="form-control" id="Inputnama" aria-describedby="HelpName" placeholder="Enter Nama">
                                </div>
                               
                                <div class="mb-3 form group">
                                    <label for="jk">Jenis Kelamin</label>
                                    <select name="jenis_kelamin" class= "form-control" id="jk">
                                        <option value="Laki-Laki">Laki-Laki</option>
                                        <option value="Perempuan">Perempuan</option>

                                    </select>
                                    
                                </div>
                                    
                                <div class="mb-3">
                                    <label for="Inputagama" class="form-label">Agama</label>
                                    <input name="agama" 6type="text" class="form-control" id="Inputagama" aria-describedby="HelpAgama" placeholder="Enter Agama">
                                </div>

                                <div class="mb-3">
                                    <label for="floatingTextarea2" class="form-label">Alamat</label>
                                    <textarea name="alamat" class="form-control" placeholder="Alamat" id="floatingTextarea2" style="height: 100px"></textarea>
                                    
                                </div>  
                                
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Submit</button>
                            </form>
                        </div>
                        </div>
                    </div>
                    
   <?php $__env->stopSection(); ?>

       


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\projek1\resources\views/pegawai/index.blade.php ENDPATH**/ ?>