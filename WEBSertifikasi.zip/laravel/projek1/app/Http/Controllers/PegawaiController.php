<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PegawaiController extends Controller
{
     public function index(Request $request)
     {
        if($request->has('cari')){
            $data_pegawai= \App\Models\pegawai::where('Nama','LIKE','%'.$request->cari.'%')->get();
        }else{
           $data_pegawai = \App\Models\pegawai::all();
        }
        return view('pegawai.index',['data_pegawai'=> $data_pegawai]);
     }
     public function create(Request $request)
     {
        \App\Models\pegawai::create($request->all());
        return redirect('/dataPegawai')->with('Berhasil','Data Pegawai berhasil di input!');
     }

     public function edit($id)
     {
         $pegawai = \App\Models\pegawai::find($id);
         return view('/pegawai/edit',['pegawai'=> $pegawai]);
     }

     public function update(Request $request,$id)
     {
      $pegawai = \App\Models\pegawai::find($id);
      $pegawai->update($request->all());
      return redirect('/dataPegawai')->with('Berhasil','Data Berhasil di Update!');
   }

   public function delete($id)
     {
      $pegawai = \App\Models\pegawai::find($id);
      $pegawai->delete($pegawai);
      return redirect('/dataPegawai')->with('Berhasil', 'Data Berhasil di Hapus!');

   }

}
