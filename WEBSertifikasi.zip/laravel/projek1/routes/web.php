<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('welcome');
// });

    Route::get('/dataPegawai','App\Http\Controllers\PegawaiController@index');
    Route::post('/dataPegawai/create','App\Http\Controllers\PegawaiController@create');
    Route::get('/dataPegawai/{id}/edit','App\Http\Controllers\PegawaiController@edit');
    Route::post('/dataPegawai/{id}/update','App\Http\Controllers\PegawaiController@update');
    Route::get('/dataPegawai/{id}/delete','App\Http\Controllers\PegawaiController@delete');
    Route::get('/','App\Http\Controllers\SiteController@home');
    